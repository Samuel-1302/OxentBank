/* ========================================
   OxenteBank - JavaScript Principal
   Funcionalidades: Menu, Carrossel, Carrinho, Animações
   Nível: Básico/Intermediário
   ======================================== */

// ============================================
// 1. IDENTIFICAÇÃO DE PÁGINA ATIVA NO MENU
// ============================================
function setActiveMenuLink() {
  // Pega o caminho atual da página
  var currentPage = window.location.pathname.split('/').pop();
  
  // Se estiver na raiz, considera como index.html
  if (currentPage === '' || currentPage === '/') {
    currentPage = 'index.html';
  }
  
  // Seleciona todos os links do menu
  var menuLinks = document.querySelectorAll('.nav-menu a');
  
  // Remove a classe active de todos os links
  menuLinks.forEach(function(link) {
    link.classList.remove('active');
    
    // Pega o href do link
    var linkHref = link.getAttribute('href');
    
    // Se o href corresponde à página atual, adiciona a classe active
    if (linkHref === currentPage || linkHref === './' + currentPage || linkHref === '../' + currentPage) {
      link.classList.add('active');
    }
    
    // Caso especial para a home
    if (currentPage === 'index.html' && (linkHref === 'index.html' || linkHref === '../index.html' || linkHref === './')) {
      link.classList.add('active');
    }
  });
}

// ============================================
// 2. MENU HAMBURGER (MOBILE)
// ============================================
function initMobileMenu() {
  var hamburger = document.querySelector('.hamburger');
  var navMenu = document.querySelector('.nav-menu');
  
  if (hamburger && navMenu) {
    // Quando clicar no hamburger
    hamburger.addEventListener('click', function() {
      // Toggle (adiciona se não tem, remove se tem) a classe active
      hamburger.classList.toggle('active');
      navMenu.classList.toggle('active');
    });
    
    // Fechar menu ao clicar em um link
    var menuLinks = document.querySelectorAll('.nav-menu a');
    menuLinks.forEach(function(link) {
      link.addEventListener('click', function() {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
      });
    });
    
    // Fechar menu ao clicar fora dele
    document.addEventListener('click', function(event) {
      var isClickInsideMenu = navMenu.contains(event.target);
      var isClickOnHamburger = hamburger.contains(event.target);
      
      if (!isClickInsideMenu && !isClickOnHamburger && navMenu.classList.contains('active')) {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
      }
    });
  }
}

// ============================================
// 3. CARROSSEL DE IMAGENS
// ============================================
function initCarousel(carouselId) {
  var carousel = document.getElementById(carouselId);
  
  if (!carousel) return;
  
  var items = carousel.querySelectorAll('.carousel-item');
  var prevBtn = carousel.querySelector('.carousel-prev');
  var nextBtn = carousel.querySelector('.carousel-next');
  var indicators = carousel.querySelectorAll('.carousel-indicator');
  
  var currentIndex = 0;
  var autoplayInterval;
  var autoplayDelay = 5000; // 5 segundos
  
  // Função para mostrar um slide específico
  function showSlide(index) {
    // Remove active de todos os itens
    items.forEach(function(item) {
      item.classList.remove('active');
    });
    
    // Remove active de todos os indicadores
    indicators.forEach(function(indicator) {
      indicator.classList.remove('active');
    });
    
    // Ajusta o índice se for maior que o número de slides
    if (index >= items.length) {
      currentIndex = 0;
    } else if (index < 0) {
      currentIndex = items.length - 1;
    } else {
      currentIndex = index;
    }
    
    // Adiciona active ao item e indicador atual
    items[currentIndex].classList.add('active');
    if (indicators[currentIndex]) {
      indicators[currentIndex].classList.add('active');
    }
  }
  
  // Função para próximo slide
  function nextSlide() {
    showSlide(currentIndex + 1);
  }
  
  // Função para slide anterior
  function prevSlide() {
    showSlide(currentIndex - 1);
  }
  
  // Event listeners dos botões
  if (prevBtn) {
    prevBtn.addEventListener('click', function() {
      prevSlide();
      resetAutoplay();
    });
  }
  
  if (nextBtn) {
    nextBtn.addEventListener('click', function() {
      nextSlide();
      resetAutoplay();
    });
  }
  
  // Event listeners dos indicadores
  indicators.forEach(function(indicator, index) {
    indicator.addEventListener('click', function() {
      showSlide(index);
      resetAutoplay();
    });
  });
  
  // Autoplay
  function startAutoplay() {
    autoplayInterval = setInterval(nextSlide, autoplayDelay);
  }
  
  function stopAutoplay() {
    clearInterval(autoplayInterval);
  }
  
  function resetAutoplay() {
    stopAutoplay();
    startAutoplay();
  }
  
  // Pausar autoplay ao passar o mouse
  carousel.addEventListener('mouseenter', stopAutoplay);
  carousel.addEventListener('mouseleave', startAutoplay);
  
  // Iniciar carrossel
  showSlide(0);
  startAutoplay();
}

// ============================================
// 4. CONTADOR DO CARRINHO
// ============================================
var ShoppingCart = {
  // Pega o contador do localStorage ou inicia em 0
  getCount: function() {
    var count = localStorage.getItem('cartCount');
    return count ? parseInt(count) : 0;
  },
  
  // Salva o contador no localStorage
  setCount: function(count) {
    localStorage.setItem('cartCount', count);
    this.updateDisplay();
  },
  
  // Adiciona item ao carrinho
  addItem: function() {
    var currentCount = this.getCount();
    this.setCount(currentCount + 1);
  },
  
  // Remove item do carrinho
  removeItem: function() {
    var currentCount = this.getCount();
    if (currentCount > 0) {
      this.setCount(currentCount - 1);
    }
  },
  
  // Limpa o carrinho
  clearCart: function() {
    this.setCount(0);
  },
  
  // Atualiza o display do contador
  updateDisplay: function() {
    var cartCountElement = document.querySelector('.cart-count');
    if (cartCountElement) {
      var count = this.getCount();
      cartCountElement.textContent = count;
      
      // Adiciona animação ao atualizar
      cartCountElement.style.transform = 'scale(1.3)';
      setTimeout(function() {
        cartCountElement.style.transform = 'scale(1)';
      }, 200);
    }
  },
  
  // Inicializa o carrinho
  init: function() {
    this.updateDisplay();
    
    // Event listeners para botões de adicionar ao carrinho
    var addButtons = document.querySelectorAll('.add-to-cart');
    addButtons.forEach(function(button) {
      button.addEventListener('click', function() {
        ShoppingCart.addItem();
        
        // Feedback visual
        var originalText = button.textContent;
        button.textContent = 'Adicionado!';
        button.style.backgroundColor = '#28a745';
        
        setTimeout(function() {
          button.textContent = originalText;
          button.style.backgroundColor = '';
        }, 1500);
      });
    });
    
    // Event listener para o ícone do carrinho
    var cartIcon = document.querySelector('.cart-icon');
    if (cartIcon) {
      cartIcon.addEventListener('click', function() {
        alert('Itens no carrinho: ' + ShoppingCart.getCount());
      });
    }
  }
};

// ============================================
// 5. MODAIS (LOGIN/CADASTRO)
// ============================================
function initModals() {
  // Função para abrir modal
  function openModal(modalId) {
    var modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.add('active');
      document.body.style.overflow = 'hidden'; // Previne scroll do body
    }
  }
  
  // Função para fechar modal
  function closeModal(modal) {
    if (modal) {
      modal.classList.remove('active');
      document.body.style.overflow = ''; // Restaura scroll do body
    }
  }
  
  // Event listeners para botões que abrem modais
  var modalTriggers = document.querySelectorAll('[data-modal]');
  modalTriggers.forEach(function(trigger) {
    trigger.addEventListener('click', function(e) {
      e.preventDefault();
      var modalId = trigger.getAttribute('data-modal');
      openModal(modalId);
    });
  });
  
  // Event listeners para botões de fechar
  var closeButtons = document.querySelectorAll('.modal-close');
  closeButtons.forEach(function(button) {
    button.addEventListener('click', function() {
      var modal = button.closest('.modal');
      closeModal(modal);
    });
  });
  
  // Fechar modal ao clicar fora do conteúdo
  var modals = document.querySelectorAll('.modal');
  modals.forEach(function(modal) {
    modal.addEventListener('click', function(e) {
      if (e.target === modal) {
        closeModal(modal);
      }
    });
  });
  
  // Fechar modal com tecla ESC
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      var activeModal = document.querySelector('.modal.active');
      if (activeModal) {
        closeModal(activeModal);
      }
    }
  });
}

// ============================================
// 6. SCROLL SUAVE
// ============================================
function initSmoothScroll() {
  var scrollLinks = document.querySelectorAll('a[href^="#"]');
  
  scrollLinks.forEach(function(link) {
    link.addEventListener('click', function(e) {
      var href = link.getAttribute('href');
      
      // Ignora links vazios
      if (href === '#' || href === '') return;
      
      e.preventDefault();
      
      var targetId = href.substring(1);
      var targetElement = document.getElementById(targetId);
      
      if (targetElement) {
        targetElement.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });
}

// ============================================
// 7. ANIMAÇÃO AO SCROLL
// ============================================
function initScrollAnimations() {
  var animatedElements = document.querySelectorAll('.scroll-animate');
  
  // Se não houver elementos para animar, retorna
  if (animatedElements.length === 0) return;
  
  // Cria um Intersection Observer
  var observer = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry) {
      if (entry.isIntersecting) {
        // Adiciona a classe visible quando o elemento entra na viewport
        entry.target.classList.add('visible');
      }
    });
  }, {
    threshold: 0.1, // Ativa quando 10% do elemento estiver visível
    rootMargin: '0px 0px -50px 0px' // Começa a animação um pouco antes
  });
  
  // Observa cada elemento
  animatedElements.forEach(function(element) {
    observer.observe(element);
  });
}

// ============================================
// 8. HEADER COM EFEITO DE SCROLL
// ============================================
function initHeaderScroll() {
  var header = document.querySelector('header');
  var scrollThreshold = 100;
  
  if (header) {
    window.addEventListener('scroll', function() {
      if (window.scrollY > scrollThreshold) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    });
  }
}

// ============================================
// 9. VALIDAÇÃO DE FORMULÁRIOS
// ============================================
function initFormValidation() {
  var forms = document.querySelectorAll('form[data-validate]');
  
  forms.forEach(function(form) {
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      
      var isValid = true;
      var inputs = form.querySelectorAll('.form-control');
      
      // Valida cada input
      inputs.forEach(function(input) {
        if (!validateInput(input)) {
          isValid = false;
        }
      });
      
      // Se o formulário for válido
      if (isValid) {
        // Aqui você pode enviar o formulário ou fazer outras ações
        alert('Formulário enviado com sucesso!');
        form.reset();
        
        // Remove classes de erro
        inputs.forEach(function(input) {
          input.classList.remove('invalid');
        });
      }
    });
    
    // Validação em tempo real
    var inputs = form.querySelectorAll('.form-control');
    inputs.forEach(function(input) {
      input.addEventListener('blur', function() {
        validateInput(input);
      });
      
      input.addEventListener('input', function() {
        if (input.classList.contains('invalid')) {
          validateInput(input);
        }
      });
    });
  });
}

// Função auxiliar para validar um input específico
function validateInput(input) {
  var isValid = true;
  
  // Verifica se o campo é obrigatório e está vazio
  if (input.hasAttribute('required') && input.value.trim() === '') {
    isValid = false;
  }
  
  // Validação de email
  if (input.type === 'email' && input.value.trim() !== '') {
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(input.value)) {
      isValid = false;
    }
  }
  
  // Validação de telefone (formato brasileiro básico)
  if (input.type === 'tel' && input.value.trim() !== '') {
    var phoneRegex = /^\(?[1-9]{2}\)? ?[0-9]{4,5}-?[0-9]{4}$/;
    if (!phoneRegex.test(input.value)) {
      isValid = false;
    }
  }
  
  // Adiciona ou remove classe de erro
  if (!isValid) {
    input.classList.add('invalid');
  } else {
    input.classList.remove('invalid');
  }
  
  return isValid;
}

// ============================================
// 10. CARDS EXPANSÍVEIS (ACORDEÃO)
// ============================================
function initAccordion() {
  var accordionButtons = document.querySelectorAll('.accordion-btn');
  
  accordionButtons.forEach(function(button) {
    button.addEventListener('click', function() {
      var content = this.nextElementSibling;
      var isActive = this.classList.contains('active');
      
      // Fecha todos os acordeões
      var allButtons = document.querySelectorAll('.accordion-btn');
      var allContents = document.querySelectorAll('.accordion-content');
      
      allButtons.forEach(function(btn) {
        btn.classList.remove('active');
      });
      
      allContents.forEach(function(cnt) {
        cnt.style.maxHeight = null;
        cnt.classList.remove('active');
      });
      
      // Se o acordeão clicado não estava ativo, abre ele
      if (!isActive) {
        this.classList.add('active');
        content.classList.add('active');
        content.style.maxHeight = content.scrollHeight + 'px';
      }
    });
  });
}

// ============================================
// INICIALIZAÇÃO QUANDO A PÁGINA CARREGAR
// ============================================
document.addEventListener('DOMContentLoaded', function() {
  console.log('OxenteBank - Site carregado!');
  
  // Inicializa todas as funcionalidades
  setActiveMenuLink();
  initMobileMenu();
  initCarousel('testimonials-carousel');
  initCarousel('gallery-carousel');
  ShoppingCart.init();
  initModals();
  initSmoothScroll();
  initScrollAnimations();
  initHeaderScroll();
  initFormValidation();
  initAccordion();
});
